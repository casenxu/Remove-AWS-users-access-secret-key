import json
import boto3
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

users = os.environ['exclusions']
listuserstoexclude = users.split()

def handler(event, context):
    client = boto3.client('iam')
    response = client.list_users()
    for u in response['Users']:
        if not (u['UserName'] in listuserstoexclude):
            logger.info("I'm checking the username: " + u['UserName'] )
            accesskeys = client.list_access_keys(UserName=u['UserName'])
            for acc in accesskeys['AccessKeyMetadata']: # this should be max 2 elements for now but you can't know in the future
                username = acc['UserName']
                logger.info("print user: " + username )
                accesskeyid = acc['AccessKeyId']
                logger.info("print accesskeyid: " + accesskeyid )
                deletionresponse = client.delete_access_key(UserName=username, AccessKeyId=accesskeyid)
                logger.info("print deletion response".format(deletionresponse))
